

#import <UIKit/UIKit.h>
#import "HeaderView.h"

@class LSDpullListMenu;


@protocol LSDropdownMenuDelegate <NSObject>

@optional

- (void)dropdownMenuWillShow:(LSDpullListMenu *)menu;    // 当下拉菜单将要显示时调用
- (void)dropdownMenuDidShow:(LSDpullListMenu *)menu;     // 当下拉菜单已经显示时调用
- (void)dropdownMenuWillHidden:(LSDpullListMenu *)menu;  // 当下拉菜单将要收起时调用
- (void)dropdownMenuDidHidden:(LSDpullListMenu *)menu;   // 当下拉菜单已经收起时调用

- (void)dropdownMenu:(LSDpullListMenu *)menu selectedCellNumber:(NSInteger)number; // 当选择某个选项时调用
-(void)passSearchString:(NSString*)seaechListStr;

@end




@interface LSDpullListMenu : UIView <UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UIButton * mainBtn;  // 主按钮 可以自定义样式 可在.m文件中修改默认的一些属性

@property (nonatomic, assign) id <LSDropdownMenuDelegate>delegate;


- (void)setMenuTitles:(NSArray *)titlesArr withRightArray:(NSArray *)rightArray rowHeight:(CGFloat)rowHeight addRight:(BOOL)isAdd;  // 设置下拉菜单控件样式

- (void)showDropDown; // 显示下拉菜单
- (void)hideDropDown; // 隐藏下拉菜单
@property(nonatomic,assign)BOOL isAddRightList;
@property(nonatomic,assign)BOOL isAddRightShow;


-(void)hideenRightList;
-(void)showRightList;

@end
