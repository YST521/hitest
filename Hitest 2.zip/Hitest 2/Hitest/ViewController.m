
    //

    #import "ViewController.h"
    #import "LSDpullListMenu.h"
    #import "ArrowAngleView.h"
    #import "HeaderView.h"





    #define SceneWidth [UIScreen mainScreen].bounds.size.width
    #define SceneHeight  [UIScreen mainScreen].bounds.size.height

    @interface ViewController ()<UITableViewDelegate,UITableViewDataSource,LSDropdownMenuDelegate,ArrowAngleViewDelegate>

    @property(nonatomic,strong)UITableView *tb;
//    @property(nonatomic,strong)UIView      *headView;
    @property(nonatomic,strong)NSMutableArray *dataArrray;
@property(nonatomic,strong)NSMutableArray *listArray;
@property(nonatomic,strong) LSDpullListMenu * rdropdownMen;
@property(nonatomic,strong) LSDpullListMenu * RrdropdownMen;
@property(nonatomic,strong)ArrowAngleView *ARvIEW;
@property(nonatomic,strong)ArrowAngleView *Aview;
@property(nonatomic,strong)UIView *menuLview;
@property(nonatomic,strong)HeaderView *headView;

    @end

    static NSString *cellID = @"cellid";

    @implementation ViewController

    -(NSMutableArray *)dataArrray{
        if (!_dataArrray) {
            _dataArrray=[NSMutableArray array];
        }
        return _dataArrray;
    }

    - (void)viewDidLoad {
        [super viewDidLoad];
        // Do any additional setup after loading the view, typically from a nib.
        [self requqestData];
        [self creatUI];
        
        
        NSMutableArray *aa =[NSMutableArray array];
        if ( [aa isMemberOfClass:[NSArray class]]) {
            NSLog(@"((((((((((((((((((99999999999999999");
        }
     
        if ( [aa isMemberOfClass:[NSMutableArray class]]) {
            NSLog(@"((((((((((((((((((ooooooooooo");
        }
        
        if ( [aa isKindOfClass:[NSArray class]]) {
            NSLog(@"((((((((((((((((((888888888");
        }
        if ( [aa isMemberOfClass:[aa class]]) {
            NSLog(@"((((((((((((((((((7777777777");
        }
        
//        
//        对于UIView
//        的两个方法的讲解：
//        
//        -
//        (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
//        
//        -
//        (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
//        
//
//        hitTest”等等。


    }

    -(void)requqestData{
        for (int i =0 ; i<50 ; i++) {
            [self.dataArrray addObject:[NSString stringWithFormat:@"%d",i]];
        }

        self.listArray =(NSMutableArray*)@[@"1111",@"222",@"333",@"444",@"555",@"666",@"777",@"888"];
        
        
    }
//http://blog.csdn.net/dayuqi/article/details/49515929

//-  (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event{
//
//
//    return YES;
//}

//-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event{
//
//    return ;
//}



    -(void)creatUI{

        self.tb =[[UITableView alloc]initWithFrame:self.view.bounds style:(UITableViewStylePlain)];
        [self.view addSubview:self.tb];
        
        self.tb.dataSource = self;
        self.tb.delegate = self;
        [self.tb registerClass:[UITableViewCell class] forCellReuseIdentifier:cellID];
        
        self.headView =[[HeaderView alloc]init];
        self.headView.frame =CGRectMake(0, 0, SceneWidth , 200);
        self.headView.backgroundColor =[UIColor greenColor];
        self.tb.tableHeaderView = self.headView;
        
      NSMutableArray*aa =(NSMutableArray*)@[@"aa",@"bb",@"cc",@"dd",@"bb",@"cc",@"dd",@"bb",@"cc",@"dd"];
        
        self.RrdropdownMen = [[LSDpullListMenu alloc] init];
        [self.RrdropdownMen setFrame:CGRectMake(0, 100, SceneWidth/2, 39)];
        //        self.rdropdownMen.alpha=0.1;
        [self.RrdropdownMen setMenuTitles:self.listArray withRightArray:aa  rowHeight:30 addRight:YES];
        self.RrdropdownMen.delegate = self;
        [self.RrdropdownMen.mainBtn setTitle:@"type" forState:(UIControlStateNormal)];
     
        [self.headView addSubview:self.RrdropdownMen];
        
        
        NSMutableArray*bb =(NSMutableArray*)@[@"aa",@"bb",@"cc",@"dd",@"bb",@"cc",@"dd",@"bb",@"cc",@"dd",@"bb",@"cc",@"dd"];
        
        self.rdropdownMen = [[LSDpullListMenu alloc] init];
        [self.rdropdownMen setFrame:CGRectMake( SceneWidth/2, 100, SceneWidth/2, 39)];
     
        [self.rdropdownMen setMenuTitles:bb withRightArray:bb  rowHeight:30 addRight:NO];
        self.rdropdownMen.delegate = self;
        [self.rdropdownMen.mainBtn setTitle:@"type1" forState:(UIControlStateNormal)];
        
        [self.headView addSubview:self.rdropdownMen];


    }


-(void)btnAction{


}


 - (void)didSelectedWithIndexPath:(NSInteger)indexpath{

    NSLog(@"8888888888888******%@",self.dataArrray[indexpath]);

}


 -(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

        return self.dataArrray.count;
    
    }

 -(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
        UITableViewCell *cell =[self.tb dequeueReusableCellWithIdentifier:cellID   ];

        cell.textLabel.text = self.dataArrray[indexPath.row];
        
        return cell;
    }

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
   
    
    self.headView.backgroundColor =[UIColor colorWithRed:arc4random_uniform(256)/255.0 green:arc4random_uniform(256)/255.0 blue:arc4random_uniform(256)/255.0 alpha:1];

}

    #pragma mark----------pullListLSDDelegate-------------


    - (void)dropdownMenu:(LSDpullListMenu *)menu selectedCellNumber:(NSInteger)number{
        if (menu == self.rdropdownMen) {
            NSLog(@"你选择了：%ld",number);
        }
      
    }

    - (void)dropdownMenuWillShow:(LSDpullListMenu *)menu{
        NSLog(@"--将要显示--");
        if (menu ==  self.RrdropdownMen) {
            
            [ self.rdropdownMen hideDropDown] ;
            
            
        }
        if (menu ==  self.rdropdownMen) {
            [ self.RrdropdownMen hideDropDown] ;
        }
    
        
    }
    - (void)dropdownMenuDidShow:(LSDpullListMenu *)menu{
        NSLog(@"--已经显示--");

    }

    - (void)dropdownMenuWillHidden:(LSDpullListMenu *)menu{
        NSLog(@"--将要隐藏--");
  
    }
    - (void)dropdownMenuDidHidden:(LSDpullListMenu *)menu{
        NSLog(@"--已经隐藏--");
//         self.headView.frame =CGRectMake(0, 0, SceneWidth , 200);
        self.headView.aa = @"666";
        
    }
    -(void)passSearchString:(NSString *)seaechListStr{
        NSLog(@"***************%@",seaechListStr);
//           self.menuLview.hidden = YES;
    }


    - (void)didReceiveMemoryWarning {
        [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
    }


    @end
