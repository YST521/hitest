

#import "ArrowAngleView.h"
#import <objc/runtime.h>
//CGFloat const ArrowSpace      = 20;
NSString const *dataArrayKey  = @"dataArrayKey";

@interface ArrowAngleView ()<UITableViewDataSource,UITableViewDelegate>


@property (assign, nonatomic) CGFloat x;
@property (assign, nonatomic) CGFloat y;
@property (assign, nonatomic) CGFloat width;

@property (assign, nonatomic) CGFloat superX;
@property (assign, nonatomic) CGFloat superY;
@end

@implementation ArrowAngleView

- (NSMutableArray *)dataArray{
    return objc_getAssociatedObject(self, &dataArrayKey);
}

- (void)setDataArray:(NSMutableArray *)dataArray{
    objc_setAssociatedObject(self, &dataArrayKey, dataArray, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (void)setTabelView:(CGRect)frame{
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:(CGRectMake(0, 0, frame.size.width, self.dataArray.count * 44>300?300:self.dataArray.count * 44))];
    tableView.backgroundColor = self.backgroundColor;
    tableView.delegate = self;
    tableView.dataSource = self;
    [tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:tableView];
}


- (void)setTargetRect:(CGRect)targetRect{
    self.x = targetRect.origin.x;
    self.y = targetRect.origin.y;
    self.width = targetRect.size.width;
    [self setNeedsDisplay];
}

- (void)drawArrowRectangle:(CGRect)frame{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextBeginPath(context);
//    NSLog(@"%@",NSStringFromCGRect(frame));
    //启始位置坐标x，y
    CGFloat origin_x = frame.origin.x;
    CGFloat origin_y = frame.origin.y;
    //第一条线的位置坐标
    CGFloat line_1_x = origin_x;
//    CGFloat line_1_y = frame.size.height;
    CGFloat line_1_y = self.dataArray.count * 44>300?300:self.dataArray.count * 44;
    //第二条线的位置坐标
    CGFloat line_2_x = frame.size.width;
    CGFloat line_2_y = line_1_y;
    //第三条线的位置坐标
    CGFloat line_3_x = line_2_x;
    CGFloat line_3_y = origin_y;
    
    CGContextMoveToPoint(context, origin_x, origin_y);
    
    CGContextAddLineToPoint(context, line_1_x, line_1_y);
    CGContextAddLineToPoint(context, line_2_x, line_2_y);
    CGContextAddLineToPoint(context, line_3_x, line_3_y);
    CGContextAddLineToPoint(context, line_3_x, origin_x);
    
    CGContextClosePath(context);
    
    UIColor *costomColor = [UIColor cyanColor];
    CGContextSetFillColorWithColor(context, costomColor.CGColor);
    
    CGContextFillPath(context);
}

- (void)drawRect:(CGRect)rect{
    
    //绘制
    [self drawArrowRectangle:rect];
    [self setTabelView:rect];
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.superX = frame.origin.x;
        self.superY = frame.origin.y;
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    cell.textLabel.font = [UIFont systemFontOfSize:14.f];
    cell.textLabel.text = self.dataArray[indexPath.row];
    cell.backgroundColor = [UIColor cyanColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.delegate didSelectedWithIndexPath:indexPath.row];
    [self removeFromSuperview];
}



@end
