

#import <UIKit/UIKit.h>

@interface HeaderView : UIView
@property(nonatomic,strong)NSString *aa;

@end
