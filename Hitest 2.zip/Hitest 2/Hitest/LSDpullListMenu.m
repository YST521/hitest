
    //

 #import "LSDpullListMenu.h"
#import "HeaderView.h"




#define SceneWidth [UIScreen mainScreen].bounds.size.width
#define SceneHeight  [UIScreen mainScreen].bounds.size.height

    #define VIEW_CENTER(aView)       ((aView).center)
    #define VIEW_CENTER_X(aView)     ((aView).center.x)
    #define VIEW_CENTER_Y(aView)     ((aView).center.y)

    #define FRAME_ORIGIN(aFrame)     ((aFrame).origin)
    #define FRAME_X(aFrame)          ((aFrame).origin.x)
    #define FRAME_Y(aFrame)          ((aFrame).origin.y)

    #define FRAME_SIZE(aFrame)       ((aFrame).size)
    #define FRAME_HEIGHT(aFrame)     ((aFrame).size.height)
    #define FRAME_WIDTH(aFrame)      ((aFrame).size.width)



    #define VIEW_BOUNDS(aView)       ((aView).bounds)

    #define VIEW_FRAME(aView)        ((aView).frame)

    #define VIEW_ORIGIN(aView)       ((aView).frame.origin)
    #define VIEW_X(aView)            ((aView).frame.origin.x)
    #define VIEW_Y(aView)            ((aView).frame.origin.y)

    #define VIEW_SIZE(aView)         ((aView).frame.size)
    #define VIEW_HEIGHT(aView)       ((aView).frame.size.height)
    #define VIEW_WIDTH(aView)        ((aView).frame.size.width)


    #define VIEW_X_Right(aView)      ((aView).frame.origin.x + (aView).frame.size.width)
    #define VIEW_Y_Bottom(aView)     ((aView).frame.origin.y + (aView).frame.size.height)

    #define AnimateTime 0.25f   // 下拉动画时间
   #define AnimateTime_list 0.20f   // 下拉动画时间



    @implementation LSDpullListMenu
    {
        UIImageView * _arrowMark;   // 尖头图标
        HeaderView     * _listView;    // 下拉列表背景View
           HeaderView     * _bgView;    // 下拉列表背景View
        UITableView * _tableView;   // 下拉列表
        UITableView * _rightTabView;   // 下拉列表
        
        NSArray     * _titleArr;    // 选项数组
        NSArray     * _rightArry;    // 选项数组
        CGFloat       _rowHeight;   // 下拉列表行高
        
        BOOL           isAddRight;
    }

    - (id)initWithFrame:(CGRect)frame{
        self = [super initWithFrame:frame];
        if (self) {
            
            [self createMainBtnWithFrame:frame];
        }
        return self;
    }

    - (void)setFrame:(CGRect)frame{
        [super setFrame:frame];
        
        [self createMainBtnWithFrame:frame];
    }


    - (void)createMainBtnWithFrame:(CGRect)frame{
        
        [_mainBtn removeFromSuperview];
        _mainBtn = nil;
        
        // 主按钮 显示在界面上的点击按钮
        // 样式可以自定义
        _mainBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_mainBtn setFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        [_mainBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
    //    [_mainBtn setTitle:self.btnString forState:(UIControlStateNormal)];
        
        
    //    [_mainBtn setTitle:@"请选择" forState:UIControlStateNormal];
        [_mainBtn addTarget:self action:@selector(clickMainBtn:) forControlEvents:UIControlEventTouchUpInside];
        _mainBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _mainBtn.titleLabel.font    = [UIFont systemFontOfSize:14.f];
        _mainBtn.titleEdgeInsets    = UIEdgeInsetsMake(0, 15, 0, 0);
        _mainBtn.selected           = NO;
        [_mainBtn setTitleColor:[UIColor lightGrayColor] forState:(UIControlStateNormal)];
    //    _mainBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        _mainBtn.backgroundColor    = [UIColor whiteColor];
        _mainBtn.layer.borderColor  = [UIColor lightGrayColor].CGColor;


        _mainBtn.layer.borderWidth  = 1;
        
        [self addSubview:_mainBtn];
              // 旋转尖头
        _arrowMark = [[UIImageView alloc] initWithFrame:CGRectMake(_mainBtn.frame.size.width - 15, 0, 9, 9)];
        _arrowMark.center = CGPointMake(VIEW_CENTER_X(_arrowMark), VIEW_HEIGHT(_mainBtn)/2);
        _arrowMark.image  = [UIImage imageNamed:@"dropdownMenu_cornerIcon.png"];
        [_mainBtn addSubview:_arrowMark];
        
    }


- (void)setMenuTitles:(NSArray *)titlesArr withRightArray:(NSArray *)rightArray rowHeight:(CGFloat)rowHeight addRight:(BOOL)isAdd{
    
        if (self == nil) {
            return;
        }

    self.backgroundColor =[UIColor redColor];
    
    //     [_mainBtn setTitle:_titleArr[0] forState:UIControlStateNormal];
        _titleArr  = [NSArray arrayWithArray:titlesArr];
         _rightArry  = [NSArray arrayWithArray:rightArray];
        _rowHeight = rowHeight;
       isAddRight = isAdd;
    
    NSLog(@"***********_ti==%@",_titleArr);
        NSLog(@"*****AAAAAAAAAAAAAAAAAAAAAAAA******");
    
    _bgView =[[HeaderView alloc]init];
    if (isAdd) {
        _bgView.frame = CGRectMake(VIEW_X(self) , VIEW_Y_Bottom(self), self.frame.size.width*2,  rowHeight*_rightArry.count);
    } else {
        _bgView.frame = CGRectMake(VIEW_X(self) , VIEW_Y_Bottom(self), self.frame.size.width,  rowHeight*_titleArr.count);
    }
    
    _bgView.backgroundColor =[UIColor colorWithWhite:0.000001 alpha:0.011];
    _bgView.backgroundColor= [UIColor orangeColor];
      _bgView.hidden = NO;
        
        // 下拉列表背景View
        _listView = [[HeaderView alloc] init];
        _listView.frame = CGRectMake(0 , 0, self.frame.size.width,  0);
        _listView.clipsToBounds       = YES;
        _listView.layer.masksToBounds = NO;
        _listView.layer.borderColor   = [UIColor lightTextColor].CGColor;
        _listView.backgroundColor =[UIColor greenColor];
        _listView.layer.borderWidth   = 0.5f;
        
        
        // 下拉列表TableView
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0,_listView.frame.size.width/2, VIEW_HEIGHT(_listView))];
        _tableView.delegate        = self;
        _tableView.dataSource      = self;
        _tableView.separatorStyle  = UITableViewCellSeparatorStyleNone;
        _tableView.bounces         = NO;
        [_listView addSubview:_tableView];
       _tableView.backgroundColor =[UIColor cyanColor];
       _tableView.hidden = NO;
    
        /****************rrr*************/
        self.isAddRightList = isAdd;
           [self hideenRightList];
//        [self showRightList];
        //        self.rightListArray =(NSMutableArray*)_rightListArray;
        
        _rightTabView =[[UITableView alloc]initWithFrame:CGRectMake(_mainBtn.frame.size.width,CGRectGetMaxY(_tableView.frame), self.frame.size.width*2/3, rowHeight*_rightArry.count) style:(UITableViewStylePlain)];
        _rightTabView.backgroundColor =[UIColor redColor];
        if (self.isAddRightList) {
                 [_listView addSubview:_rightTabView];
        }
   
        
        _rightTabView.dataSource = self;
        _rightTabView.delegate = self;
        _rightTabView.backgroundColor =[UIColor redColor];
        [_rightTabView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"right"];
        
        

    }
-(void)showRightList{

//    self.isAddRightShow= YES;
    _rightTabView.hidden = NO;
}
-(void)hideenRightList{
//    self.isAddRightShow= NO;
      _rightTabView.hidden = YES;
}

    - (void)clickMainBtn:(UIButton *)button{
        
       [self.superview addSubview:_bgView];
        [_bgView addSubview:_listView]; // 将下拉视图添加到控件的父视图上
             [self hideenRightList];
        if(button.selected == NO) {
            [self showDropDown];
            _bgView.hidden = NO;
           
        }
        else {
               _bgView.hidden = YES;
            [self hideDropDown];
               [self hideenRightList];
        }
    }

    - (void)showDropDown{   // 显示下拉列表
        
        [_listView.superview bringSubviewToFront:_listView]; // 将下拉列表置于最上层
        
        
        
        if ([self.delegate respondsToSelector:@selector(dropdownMenuWillShow:)]) {
            [self.delegate dropdownMenuWillShow:self]; // 将要显示回调代理
        }
        
        
//        [UIView animateWithDuration:AnimateTime animations:^{
//            
//            _arrowMark.transform = CGAffineTransformMakeRotation(M_PI);
//            if (isAddRight) {
//                _bgView.frame = CGRectMake(VIEW_X(self) , VIEW_Y_Bottom(self), self.frame.size.width*2,  _rowHeight*_rightArry.count);
//            } else {
//                _bgView.frame = CGRectMake(VIEW_X(self) , VIEW_Y_Bottom(self), self.frame.size.width,  _rowHeight*_titleArr.count);
//            }
//            _listView.frame  = CGRectMake(VIEW_X(_listView), VIEW_Y(_listView), _listView.frame.size.width, _rowHeight *_titleArr.count);
//            _tableView.frame = CGRectMake(0, 0,_listView.frame.size.width, VIEW_HEIGHT(_listView));
//            
//        }completion:^(BOOL finished) {
//            
//            if ([self.delegate respondsToSelector:@selector(dropdownMenuDidShow:)]) {
//                [self.delegate dropdownMenuDidShow:self]; // 已经显示回调代理
//            }
//        }];

        
        [UIView animateWithDuration:AnimateTime_list animations:^{
            
            _arrowMark.transform = CGAffineTransformMakeRotation(M_PI);
            _listView.frame  = CGRectMake(VIEW_X(_listView), VIEW_Y(_listView), _listView.frame.size.width, _rowHeight *_titleArr.count);
            _tableView.frame = CGRectMake(0, 0,_listView.frame.size.width, VIEW_HEIGHT(_listView));
            
        }completion:^(BOOL finished) {
            
            if ([self.delegate respondsToSelector:@selector(dropdownMenuDidShow:)]) {
                [self.delegate dropdownMenuDidShow:self]; // 已经显示回调代理
            }
        }];
        
        
        
        
        _mainBtn.selected = YES;
    }
    - (void)hideDropDown{  // 隐藏下拉列表
        
        
        if ([self.delegate respondsToSelector:@selector(dropdownMenuWillHidden:)]) {
            [self.delegate dropdownMenuWillHidden:self]; // 将要隐藏回调代理
        }
        
        
        [UIView animateWithDuration:AnimateTime animations:^{
               _bgView.frame = CGRectMake(VIEW_X(_listView), VIEW_Y(_listView),  _listView.frame.size.width, 0);
            _arrowMark.transform = CGAffineTransformIdentity;
            _listView.frame  = CGRectMake(VIEW_X(_listView), VIEW_Y(_listView),  _listView.frame.size.width, 0);
            _tableView.frame = CGRectMake(0, 0, _listView.frame.size.width, VIEW_HEIGHT(_listView));
//            self.frame = CGRectMake(0, 0,self.frame.size.width , self.frame.size.height);
        }completion:^(BOOL finished) {
            
            if ([self.delegate respondsToSelector:@selector(dropdownMenuDidHidden:)]) {
                [self.delegate dropdownMenuDidHidden:self]; // 已经隐藏回调代理
            }
        }];
        
        
        
        _mainBtn.selected = NO;
    }

    #pragma mark - UITableView Delegate

    -(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
        
        return _rowHeight;
    }

    - (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
        
        if ( tableView ==_rightTabView) {
            return _rightArry.count;
            
        } else {
         return [_titleArr count];
            
        }
     
    }
    - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        
        if (tableView ==_rightTabView) {

            UITableViewCell *cell = [_rightTabView dequeueReusableCellWithIdentifier:@"right"];
          
                //---------------------------下拉选项样式，可在此处自定义-------------------------
//                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"right"];
                cell.textLabel.font          = [UIFont systemFontOfSize:11.f];
                cell.textLabel.textColor     = [UIColor blackColor];
//                cell.selectionStyle          = UITableViewCellSelectionStyleNone;
            
                UIView * line = [[UIView alloc] initWithFrame:CGRectMake(0, _rowHeight -0.5, VIEW_WIDTH(cell), 0.5)];
                line.backgroundColor = [UIColor blackColor];
                [cell addSubview:line];
                //---------------------------------------------------------------------------
           
           cell.textLabel.text= [_rightArry objectAtIndex:indexPath.row];

//            cell.textLabel.text =_rightListArray [indexPath.row];
            cell.textLabel.textAlignment = NSTextAlignmentCenter;
            cell.textLabel.textColor = [UIColor lightGrayColor];
            cell.textLabel.font =[UIFont systemFontOfSize:14.0];
//            cell.backgroundColor =[UIColor redColor];
        cell.backgroundColor =[UIColor whiteColor];
            return cell;
            
        } else {
          
        
        
        static NSString *CellIdentifier = @"Cell";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            //---------------------------下拉选项样式，可在此处自定义-------------------------
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            cell.textLabel.font          = [UIFont systemFontOfSize:11.f];
            cell.textLabel.textColor     = [UIColor blackColor];
//            cell.selectionStyle          = UITableViewCellSelectionStyleNone;
            
            UIView * line = [[UIView alloc] initWithFrame:CGRectMake(0, _rowHeight -0.5, VIEW_WIDTH(cell), 0.5)];
            line.backgroundColor = [UIColor blackColor];
            [cell addSubview:line];
            //---------------------------------------------------------------------------
        }
        
        cell.textLabel.text =[_titleArr objectAtIndex:indexPath.row];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor lightGrayColor];
        cell.textLabel.font =[UIFont systemFontOfSize:14.0];
//            cell.backgroundColor =[UIColor whiteColor];
        return cell;
        }
    }
    - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        
        
        if (YES) {
            
        }
           NSLog(@"*********%ld*************",(long)indexPath.row);
        
        
        
        //判断是否加二级列表
        if (tableView ==_rightTabView) {
//            http://www.jianshu.com/p/902f862f6f87
            
       
            
            NSLog(@"*********%@*************",_rightArry[indexPath.row]);
              [_mainBtn setTitle:_rightArry[indexPath.row] forState:UIControlStateNormal];
              _bgView.hidden = YES;
            [self hideenRightList];
            [self hideDropDown];
            
            
        }else{
            if (self.isAddRightList == YES) {
                
                [self showRightList];
                
            } else {
                
            
            
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
        [_mainBtn setTitle:cell.textLabel.text forState:UIControlStateNormal];
        [self.delegate passSearchString:cell.textLabel.text];
        _bgView.hidden = YES;
        if ([self.delegate respondsToSelector:@selector(dropdownMenu:selectedCellNumber:)]) {
            [self.delegate dropdownMenu:self selectedCellNumber:indexPath.row]; // 回调代理
        }
        
        [self hideDropDown];
            
        }
        
    }

//      UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
//        cell.backgroundColor =[UIColor lightGrayColor];
        
    }


    @end
